library(testthat)
library(wdman)

test_check("wdman")
