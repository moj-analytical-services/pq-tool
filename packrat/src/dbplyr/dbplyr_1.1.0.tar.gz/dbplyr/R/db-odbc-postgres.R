#' @export
sql_translate_env.PostgreSQL <- function(con) {
  sql_translate_env.PostgreSQLConnection(con)
}
