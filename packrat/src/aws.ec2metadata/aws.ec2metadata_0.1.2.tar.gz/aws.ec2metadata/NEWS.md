# CHANGES TO aws.ec2metadata 0.1.2

* Added a function `is_ec2()` that returns a logical based on whether metadata is retrievable.

# CHANGES TO aws.ec2metadata 0.1.1

* Initial release.
