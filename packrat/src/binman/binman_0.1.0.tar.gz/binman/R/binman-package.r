#' binman.
#'
#' @importFrom stats setNames
#' @importFrom assertthat assert_that
#' @name binman
#' @docType package
NULL
