
context("showimage")

test_that("showimage works", {

  expect_true(TRUE)

})
