
# 1.0.2

* Do not us `testthat::with_mock`, it interferes with the JIT that is
  default in R 3.4.0. Use the `mockery` package instead.

# 1.0.1

* Fix a test case bug.

# 1.0.0

First public release.
