## Test environments
* local OS X install, R 3.3.3

## R CMD check results

0 errors | 1 warnings | 1 note

Non-standard license specification:
  MIT license
Standardizable: FALSE

checking top-level files ... NOTE
Non-standard files/directories found at top level:
  ‘README.Rmd’ ‘cran-comments.md’

* This is a new release.

## Reverse dependencies

This is a new release, so there are no reverse dependencies.
