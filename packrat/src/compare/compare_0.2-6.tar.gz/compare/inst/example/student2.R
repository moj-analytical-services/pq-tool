#variable definition
	id <- seq(1,6)
	age <- c(30,32,28,39,20,25)
	edu <- rep(0,6)
	class<-factor(rep(c("poor","middle"),each=3))
	
	
#QUESTION #2 IndianMothers dataframe

IndianMothers <-data.frame(id,age,edu,class)

