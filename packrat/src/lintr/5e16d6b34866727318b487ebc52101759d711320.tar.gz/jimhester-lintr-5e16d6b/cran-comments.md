## Comments
This release fixes the ERRORs due to the latest testthat release.

## Test environments
* local OS X install, R 3.2.4
* ubuntu 12.04 (on travis-ci), R 3.2.4
* win-builder (devel and release)

## R CMD check results

0 errors | 0 warnings | 0 note

## Reverse dependencies

* I have run R CMD check on the 6 downstream dependencies.
  Summary at: https://github.com/jimhester/lintr/blob/master/revdep/
  There were no errors found.
