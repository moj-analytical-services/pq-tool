# Setup

## Platform

|setting  |value                        |
|:--------|:----------------------------|
|version  |R version 3.2.4 (2016-03-10) |
|system   |x86_64, darwin13.4.0         |
|ui       |X11                          |
|language |(EN)                         |
|collate  |en_US.UTF-8                  |
|tz       |America/New_York             |
|date     |2016-04-15                   |

## Packages

|package |*  |version |date       |source                  |
|:-------|:--|:-------|:----------|:-----------------------|
|lintr   |*  |1.0.0   |2016-04-15 |local (jimhester/lintr) |

# Check results
0 packages with problems


